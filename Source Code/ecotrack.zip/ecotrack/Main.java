import java.util.Scanner;

public class Main {

    private static DataStore dataStore = new DataStore();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            tampilkanMenu();
            int pilihan = bacaPilihan();
            System.out.println();
            if (pilihan == 0) {
                System.out.println("Terima kasih telah menggunakan EcoTrack!");
                System.out.println("Sampah terkelola, lingkungan terjaga!");
                break;
            }
            prosesPilihan(pilihan);
            System.out.println();
        }
        scanner.close();
    }

    private static void tampilkanMenu() {
        System.out.println("+======================================+");
        System.out.println("|        ECOTRACK — Manajemen Sampah   |");
        System.out.println("|           Komunitas RW Digital       |");
        System.out.println("+======================================+");
        System.out.println("| 1. Edukasi & Panduan Pemilahan       |");
        System.out.println("| 2. Daftar Warga Baru                 |");
        System.out.println("| 3. Catat Setoran Sampah              |");
        System.out.println("| 4. Lihat Semua Warga & Poin          |");
        System.out.println("| 5. Cek Saldo Poin Warga              |");
        System.out.println("| 6. Monitoring Gudang RW              |");
        System.out.println("| 7. Proses Organik (Kompos/Maggot)    |");
        System.out.println("| 8. Jual Anorganik ke Pengepul        |");
        System.out.println("| 9. Jual Kompos & Maggot              |");
        System.out.println("| 0. Keluar                            |");
        System.out.println("+======================================+");
        System.out.print("Pilih menu > ");
    }

    private static int bacaPilihan() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static void prosesPilihan(int pilihan) {
        switch (pilihan) {
            case 1 -> menuEdukasi();
            case 2 -> menuDaftarWarga();
            case 3 -> menuSetoran();
            case 4 -> dataStore.tampilkanSemuaWarga();
            case 5 -> menuCekSaldo();
            case 6 -> dataStore.getGudangRW().tampilkanStatus();
            case 7 -> dataStore.getGudangRW().prosesKompos();
            case 8 -> dataStore.getGudangRW().jualKePengepul();
            case 9 -> dataStore.getGudangRW().jualKomposMaggot();
            default -> System.out.println("Pilihan tidak valid. Silakan coba lagi.");
        }
    }

    private static void menuEdukasi() {
        System.out.println("+======================================+");
        System.out.println("|         PANDUAN PEMILAHAN SAMPAH     |");
        System.out.println("+======================================+");
        System.out.println("| SAMPAH ORGANIK (1 poin/kg)           |");
        System.out.println("| - Sisa makanan                       |");
        System.out.println("| - Kulit buah & sayuran               |");
        System.out.println("| - Daun kering / ranting              |");
        System.out.println("| - Ampas kopi / teh                   |");
        System.out.println("| - Sisa nasi / roti                   |");
        System.out.println("+--------------------------------------+");
        System.out.println("| SAMPAH ANORGANIK (2 poin/kg)          |");
        System.out.println("| - Botol plastik (PET)                |");
        System.out.println("| - Kardus / kertas                    |");
        System.out.println("| - Kaleng aluminium                   |");
        System.out.println("| - Kemasan plastik                    |");
        System.out.println("| - Botol kaca                         |");
        System.out.println("+--------------------------------------+");
        System.out.println("| CATATAN:                              |");
        System.out.println("| Sampah anorganik bernilai poin 2x     |");
        System.out.println("| lebih tinggi karena bisa dijual       |");
        System.out.println("| ke pengepul untuk didaur ulang.       |");
        System.out.println("+======================================+");
    }

    private static void menuDaftarWarga() {
        System.out.print("Masukkan nama warga: ");
        String nama = scanner.nextLine().trim();

        if (nama.isEmpty()) {
            System.out.println("Nama tidak boleh kosong.");
            return;
        }

        try {
            dataStore.cariWarga(nama);
            System.out.println("Warga '" + nama + "' sudah terdaftar.");
        } catch (WargaTidakDitemukanException e) {
            Warga warga = new Warga(nama);
            dataStore.tambahWarga(warga);
            System.out.println(
                "Warga '" + nama + "' berhasil didaftarkan! ID: " + warga.getId()
            );
        }
    }

    private static void menuCekSaldo() {
        System.out.print("Masukkan nama warga: ");
        String nama = scanner.nextLine().trim();

        Warga warga;
        try {
            warga = dataStore.cariWarga(nama);
        } catch (WargaTidakDitemukanException e) {
            System.out.println(e.getMessage());
            return;
        }

        System.out.println("Saldo poin '" + warga.getNama() + "': " + warga.getSaldoPoin() + " poin");

        if (warga.getSaldoPoin() < 50) {
            System.out.println("Minimal 50 poin untuk bisa ditukar (setara Rp 50.000).");
            return;
        }

        System.out.print("Tukarkan poin dengan uang? (y/n): ");
        String jawab = scanner.nextLine().trim().toLowerCase();
        if (!jawab.equals("y")) return;

        System.out.print("Jumlah poin yang ditukar (min 50, maks " + warga.getSaldoPoin() + "): ");
        int jumlah;
        try {
            jumlah = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Input tidak valid.");
            return;
        }

        if (jumlah < 50) {
            System.out.println("Minimal penukaran 50 poin.");
            return;
        }

        if (jumlah > warga.getSaldoPoin()) {
            System.out.println("Poin tidak mencukupi. Saldo Anda: " + warga.getSaldoPoin() + " poin.");
            return;
        }

        double nominal = jumlah * 1000;
        GudangRW gudang = dataStore.getGudangRW();

        if (nominal > gudang.getUangKasRW()) {
            System.out.println("Kas RW tidak mencukupi.");
            System.out.printf("Kas RW saat ini: Rp %.0f\n", gudang.getUangKasRW());
            return;
        }

        warga.kurangPoin(jumlah);
        gudang.tarikKas(nominal);

        System.out.println("+======================================+");
        System.out.println("PENUKARAN BERHASIL!");
        System.out.printf("%s menukar %d poin\n", warga.getNama(), jumlah);
        System.out.printf("Mendapatkan uang tunai Rp %,.0f\n", nominal);
        System.out.printf("Sisa saldo poin: %d poin\n", warga.getSaldoPoin());
        System.out.println("+======================================+");
    }

    private static void menuSetoran() {
        System.out.print("Masukkan nama warga: ");
        String nama = scanner.nextLine().trim();

        Warga warga;
        try {
            warga = dataStore.cariWarga(nama);
        } catch (WargaTidakDitemukanException e) {
            System.out.println(e.getMessage());
            return;
        }

        System.out.println("Jenis sampah:");
        System.out.println("1. Organik (1 poin/kg)");
        System.out.println("2. Anorganik (2 poin/kg)");
        System.out.print("Pilih jenis > ");

        int jenis;
        try {
            jenis = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Pilihan tidak valid.");
            return;
        }

        if (jenis != 1 && jenis != 2) {
            System.out.println("Pilihan tidak valid.");
            return;
        }

        System.out.print("Masukkan berat (kg): ");
        double berat;
        try {
            berat = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Berat tidak valid.");
            return;
        }

        Sampah sampah;
        if (jenis == 1) {
            sampah = new SampahOrganik(berat);
        } else {
            sampah = new SampahAnorganik(berat);
        }

        try {
            String hasil = dataStore.catatSetoran(nama, sampah);
            System.out.println("Setoran berhasil dicatat!");
            System.out.println(hasil);
        } catch (BeratTidakValidException | WargaTidakDitemukanException e) {
            System.out.println(e.getMessage());
        }
    }
}
