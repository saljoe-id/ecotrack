import java.util.Date;

public class Transaksi {
    private static int counter = 0;

    private String id;
    private Warga warga;
    private Sampah sampah;
    private Date tanggal;

    public Transaksi(Warga warga, Sampah sampah) {
        this.id = "TRX-" + (++counter);
        this.warga = warga;
        this.sampah = sampah;
        this.tanggal = new Date();
    }

    public String getId() {
        return id;
    }

    public Warga getWarga() {
        return warga;
    }

    public Sampah getSampah() {
        return sampah;
    }

    public Date getTanggal() {
        return tanggal;
    }
}
