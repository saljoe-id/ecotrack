public class Warga {
    private static int counter = 0;

    private String id;
    private String nama;
    private int saldoPoin;

    public Warga(String nama) {
        this.id = "W-" + (++counter);
        this.nama = nama;
        this.saldoPoin = 0;
    }

    public void tambahPoin(double poin) {
        this.saldoPoin += (int) poin;
    }

    public boolean kurangPoin(int poin) {
        if (poin > this.saldoPoin) return false;
        this.saldoPoin -= poin;
        return true;
    }

    public String getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public int getSaldoPoin() {
        return saldoPoin;
    }
}
