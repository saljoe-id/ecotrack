import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

public class DataStore {
    private ArrayList<Warga> daftarWarga;
    private HashMap<String, Warga> mapWarga;
    private LinkedList<Transaksi> daftarTransaksi;
    private GudangRW gudangRW;

    public DataStore() {
        daftarWarga = new ArrayList<>();
        mapWarga = new HashMap<>();
        daftarTransaksi = new LinkedList<>();
        gudangRW = new GudangRW();
    }

    public void tambahWarga(Warga w) {
        daftarWarga.add(w);
        mapWarga.put(w.getNama().toLowerCase(), w);
    }

    public Warga cariWarga(String nama) throws WargaTidakDitemukanException {
        Warga w = mapWarga.get(nama.toLowerCase());
        if (w == null) {
            throw new WargaTidakDitemukanException(nama);
        }
        return w;
    }

    public String catatSetoran(String namaWarga, Sampah sampah)
            throws WargaTidakDitemukanException, BeratTidakValidException {

        if (sampah.getBerat() <= 0) {
            throw new BeratTidakValidException(sampah.getBerat());
        }

        Warga warga = cariWarga(namaWarga);
        Transaksi trx = new Transaksi(warga, sampah);

        double poin = sampah.konversiKePoin();
        warga.tambahPoin(poin);

        daftarTransaksi.add(trx);
        gudangRW.tambahTransaksi(trx);

        return String.format(
            "%s menyetor %.2f kg %s. Poin +%.0f (Total: %d poin)",
            warga.getNama(), sampah.getBerat(), sampah.getJenis(),
            poin, warga.getSaldoPoin()
        );
    }

    public void tampilkanSemuaWarga() {
        if (daftarWarga.isEmpty()) {
            System.out.println("Belum ada warga terdaftar.");
            return;
        }
        System.out.println("+======================================+");
        System.out.println("|           DATA WARGA & POIN          |");
        System.out.println("+======================================+");
        System.out.printf("| %-8s | %-20s | %-5s |\n", "ID", "Nama", "Poin");
        System.out.println("+--------------------------------------+");
        for (Warga w : daftarWarga) {
            System.out.printf("| %-8s | %-20s | %5d |\n", w.getId(), w.getNama(), w.getSaldoPoin());
        }
        System.out.println("+======================================+");
    }

    public ArrayList<Warga> getDaftarWarga() {
        return daftarWarga;
    }

    public LinkedList<Transaksi> getDaftarTransaksi() {
        return daftarTransaksi;
    }

    public GudangRW getGudangRW() {
        return gudangRW;
    }
}
