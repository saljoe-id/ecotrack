public interface PoinKonvertible {
    double konversiKePoin();
}
