public class SampahAnorganik extends Sampah {
    private static int counter = 0;

    public SampahAnorganik(double berat) {
        super("ANORG-" + (++counter), "Anorganik", berat, 2.0);
    }

    @Override
    public double konversiKePoin() {
        return getBerat() * getKonversiPoin();
    }
}
