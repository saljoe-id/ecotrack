public class WargaTidakDitemukanException extends Exception {
    public WargaTidakDitemukanException(String nama) {
        super("Warga dengan nama '" + nama + "' tidak ditemukan.");
    }
}
