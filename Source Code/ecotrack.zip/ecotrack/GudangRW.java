public class GudangRW {
    private double totalKgOrganik;
    private double totalKgAnorganik;
    private double komposKg;
    private double maggotKg;
    private double uangKasRW;

    public GudangRW() {
        this.totalKgOrganik = 0;
        this.totalKgAnorganik = 0;
        this.komposKg = 0;
        this.maggotKg = 0;
        this.uangKasRW = 0;
    }

    public void tambahTransaksi(Transaksi t) {
        Sampah s = t.getSampah();
        if (s.getJenis().equals("Organik")) {
            totalKgOrganik += s.getBerat();
        } else {
            totalKgAnorganik += s.getBerat();
        }
    }

    public void prosesKompos() {
        if (totalKgOrganik <= 0) {
            System.out.println("Belum ada sampah organik untuk diproses.");
            return;
        }
        double rasioKompos = 0.5;
        double rasioMaggot = 0.1;
        double hasilKompos = totalKgOrganik * rasioKompos;
        double hasilMaggot = totalKgOrganik * rasioMaggot;
        komposKg += hasilKompos;
        maggotKg += hasilMaggot;

        System.out.println("========================================");
        System.out.printf("Memproses %.2f kg sampah organik\n", totalKgOrganik);
        System.out.printf("-> Kompos : %.2f kg\n", hasilKompos);
        System.out.printf("-> Maggot : %.2f kg\n", hasilMaggot);
        System.out.println("Status: Berhasil diproses!");
        System.out.println("========================================");
        totalKgOrganik = 0;
    }

    public void jualKePengepul() {
        if (totalKgAnorganik <= 0) {
            System.out.println("Belum ada sampah anorganik untuk dijual.");
            return;
        }
        double hasil = totalKgAnorganik * 5000;
        uangKasRW += hasil;
        System.out.println("========================================");
        System.out.printf("Menjual %.2f kg sampah anorganik ke pengepul\n", totalKgAnorganik);
        System.out.printf("Tarif: Rp 5.000/kg\n");
        System.out.printf("Kas RW bertambah: Rp %.0f\n", hasil);
        System.out.printf("Total Kas RW sekarang: Rp %.0f\n", uangKasRW);
        System.out.println("========================================");
        totalKgAnorganik = 0;
    }

    public void jualKomposMaggot() {
        if (komposKg <= 0 && maggotKg <= 0) {
            System.out.println("Belum ada kompos atau maggot untuk dijual.");
            return;
        }
        double hargaKompos = 3000;
        double hargaMaggot = 5000;
        double hasilKompos = komposKg * hargaKompos;
        double hasilMaggot = maggotKg * hargaMaggot;
        double totalHasil = hasilKompos + hasilMaggot;
        uangKasRW += totalHasil;

        System.out.println("========================================");
        System.out.println("Penjualan Kompos & Maggot");
        if (komposKg > 0) {
            System.out.printf("Kompos : %.2f kg x Rp 3.000 = Rp %.0f\n", komposKg, hasilKompos);
        }
        if (maggotKg > 0) {
            System.out.printf("Maggot : %.2f kg x Rp 5.000 = Rp %.0f\n", maggotKg, hasilMaggot);
        }
        System.out.printf("Total : Rp %.0f\n", totalHasil);
        System.out.printf("Total Kas RW sekarang: Rp %.0f\n", uangKasRW);
        System.out.println("========================================");
        komposKg = 0;
        maggotKg = 0;
    }

    public void tampilkanStatus() {
        System.out.println("\n+======================================+");
        System.out.println("|       MONITORING GUDANG RW           |");
        System.out.println("+======================================+");
        System.out.printf("| Sampah Organik   : %10.2f kg       |\n", totalKgOrganik);
        System.out.printf("| Sampah Anorganik : %10.2f kg       |\n", totalKgAnorganik);
        System.out.printf("| Kompos           : %10.2f kg       |\n", komposKg);
        System.out.printf("| Maggot           : %10.2f kg       |\n", maggotKg);
        System.out.printf("| Uang Kas RW      : Rp %8.0f        |\n", uangKasRW);
        System.out.println("+======================================+\n");
    }

    public double getTotalKgOrganik() {
        return totalKgOrganik;
    }

    public double getTotalKgAnorganik() {
        return totalKgAnorganik;
    }

    public boolean tarikKas(double jumlah) {
        if (jumlah > uangKasRW) return false;
        uangKasRW -= jumlah;
        return true;
    }

    public double getUangKasRW() {
        return uangKasRW;
    }
}
