public class BeratTidakValidException extends Exception {
    public BeratTidakValidException(double berat) {
        super("Berat tidak valid: " + berat + " kg. Berat harus lebih dari 0 kg.");
    }
}
