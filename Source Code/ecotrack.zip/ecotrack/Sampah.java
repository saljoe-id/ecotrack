public abstract class Sampah implements PoinKonvertible {
    private String id;
    private String jenis;
    private double berat;
    private double konversiPoin;

    public Sampah(String id, String jenis, double berat, double konversiPoin) {
        this.id = id;
        this.jenis = jenis;
        this.berat = berat;
        this.konversiPoin = konversiPoin;
    }

    public String getId() {
        return id;
    }

    public String getJenis() {
        return jenis;
    }

    public double getBerat() {
        return berat;
    }

    public double getKonversiPoin() {
        return konversiPoin;
    }
}
