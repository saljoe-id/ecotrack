public class SampahOrganik extends Sampah {
    private static int counter = 0;

    public SampahOrganik(double berat) {
        super("ORG-" + (++counter), "Organik", berat, 1.0);
    }

    @Override
    public double konversiKePoin() {
        return getBerat() * getKonversiPoin();
    }
}
